#pragma once
#include <Windows.h>
#include <iomanip>
#include <iostream>

#define xor_w(x) x //ENCRYPT_STRING_AUTO_W(encstr::ecb_t<encstr::ciphers::xor_cipher_t>, x)
#define xor_a(x) x //ENCRYPT_STRING_AUTO_A(encstr::ecb_t<encstr::ciphers::xor_cipher_t>, x)
